Thanks For Your Support >,<

Canvas size ExperimentZ #5 192x128px

This asset can be used in commercial and non-commercial.
You can modify it. Credit? I would really appreciate it >,< 
You are NOT allowed to redistribute these graphics or resell it other than packaged in your own game!!